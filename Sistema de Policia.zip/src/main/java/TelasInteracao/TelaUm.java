package TelasInteracao;

import java.util.Scanner;

public class TelaUm {

    public void telaCadastro() {

        Scanner sc = new Scanner(System.in);

        System.out.println("--------------------");
        System.out.println("  SISTEMA POLICIAL  ");
        System.out.println("--------------------");

        do {
            System.out.println(" 1 - Login \n");
            System.out.println(" 2 - Registrar \n");
            System.out.println(" 3 - Sair\n");
            int escolha = sc.nextInt();
            sc.nextLine();

            switch(escolha) {

                case 1: {

                }

                case 2: {

                }

                case 3: {

                }

                default: {
                    return;
                }
            }

        } while();
    }
}
